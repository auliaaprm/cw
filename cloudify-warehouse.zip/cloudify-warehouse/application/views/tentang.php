<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title><?= $title; ?></title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?= base_url() ?>assets/img/cw.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/responsive.css">

</head>
<body>
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="<?= base_url() ?>assets/img/random.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li><a href="<?= base_url('beranda') ?>">Beranda</a></li>
								<li class="current-list-item"><a href="<?= base_url('tentang') ?>">Tentang Kami</a></li>
								<li><a href="#">Barang</a>
									<ul class="sub-menu">
										<li><a href="<?= base_url('barang/resi') ?>">Resi</a></li>
										<li><a href="<?= base_url('barang/status') ?>">Lacak Pengiriman</a></li>
										<li><a href="<?= base_url('barang/tagihan') ?>">Transaksi</a></li>
									</ul>
								</li>
								<li><a href="<?= base_url('profil') ?>">Profil</a></li>
								<li>
									<div class="header-icons">
										<a class="shopping-cart" href=""></a>
										<a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->
	
	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<input type="text" placeholder="Keywords">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search area -->
	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
	</div>
	<!-- end breadcrumb section -->

	<!-- featured section -->
	<div class="feature-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-7">
					<div class="featured-text">
						<h2 class="pb-3"><span class="orange-text">Cloudify Warehouse</span></h2>
						<div class="row">
							
							
							<div class="col-lg-9 col-md-6">
								<div class="list-box d-flex">
									<div class="content">
                                        <p>Cloudify warehouse didirikan pada tanggal 21 Juli 2021 yang sudah
                                            memiliki cabang di Daehak-ro, Gunsan, Jeollabuk-do, Korea Selatan dan
                                            di Kp. Jati Parung, Bogor, Indonesia. </p><br>
										<p>Cloudify warehouse merupakan salah satu warehouse yang jangkauan operasionalnya 
                                            hanya sekitar Korea Selatan – Indonesia. Menawarkan jasa warehouse 
                                            dengan dua pilihan yaitu sharing dan direct. Cloudify warehouse saat ini 
                                            bekerjasama baik dengan beberapa pihak terkait seperti pihak Bea Cukai Indonesia dan Pos
                                            Indonesia.
                                        </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end featured section -->

	<!-- team section -->
	<div class="mb-150 mt-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="section-title">
						<h3>Paket <span class="orange-text">Layanan</span></h3>
						<p>Jenis paket layanan yang tersedia dalam warehouse kami</p>
					</div>
				</div>
			</div>
			<table class="table table-bordered">
			<thead>
				<tr>
					<th scope="col" class="col-lg-3 text-center">Jenis Paket</th>
					<th scope="col" class="text-center">Keterangan</th>
				</tr>
			</thead>
			<tbody>
					<tr>
						<td>Sharing</td>
						<td>Barang dari Warehouse Korea dikirim terlebih dahulu ke warehouse Indonesia, kemudian
setelah barang di sortir akan dikirim ke masing-masing alamat member. Hitungan tarif kirim dan pajak menggunakan
tarif yang ditetapkan oleh warehouse. Seluruh tahapan pengiriman barang diurus oleh pihak warehouse, barang
member akan dijadikan dalam satu box dengan barang member lain, maka dari itu member warehouse
wajib mengikuti alur dan sepakat dengan ketentuan warehouse perihal update barang, jadwal pengiriman,
penetapan rate, dan sistem warehouse.</td>
					</tr>
					<tr>
						<td>Direct (Repack)</td>
						<td>Barang kiriman dengan paket Repack ini akan dibuka oleh pihak warehouse untuk
kemudian barang di dalamnya di repacking lalu dimasukkan ke box baru. Member juga dapat
mengirim paket lebih dari satu resi, yang nantinya akan di repack ke dalam satu box yang sama
sebelum akhirnya dikirim ke alamat tujuan.</td>
					</tr>
					<tr>
						<td>Direct (No Repack)</td>
						<td>Paket direct No Repack yang dikirim ke warehouse tidak dibuka sama sekali, melainkan warehouse hanya membantu
untuk melepas invoice asli, mencetak invoice baru, merekatkan box, membantu pengiriman ke
ekspedisi. Biasanya paket No Repack ini dipakai saat ada Web atau Seller yang tidak menyediakan
pengiriman overseas atau memang member yang ingin membuat invoice baru.</td>
					</tr>
			</tbody>
			</table>
	</div>
	<!-- end team section -->

	<!-- team section -->
	<div class="mb-150 mt-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="section-title">
						<h3>Tarif <span class="orange-text">Warehouse</span></h3>
						<p>Tarif sharing yang berlaku dalam warehouse kami</p>
					</div>
				</div>
			</div>
			<table class="table table-bordered">
			<thead>
				<tr>
					<th scope="col" class="col-lg-6 text-center">Kategori</th>
					<th scope="col" class="text-center">Tarif</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($alltarif as $no => $tarif) {
				?>
					<tr>
						<td><?= $tarif['keterangan']; ?></td>
						<td class="text-center">Rp<?= number_format($tarif['tarif'],0,',','.'); ?>/pcs</td>
				<?php
				}
				?>
			</tbody>
			</table>
	</div>
	<!-- end team section -->

	<!-- team section -->
	<div class="mb-150 mt-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="section-title">
						<h3>Alamat <span class="orange-text">Warehouse</span></h3>
						<p>Gunakan alamat di bawah ini untuk mengirimkan barang Anda ke warehouse kami di Korea</p>
					</div>
				</div>
			</div>
			<div class="row">
                <div class="col-lg-6 col-md-6 text-center">
					<div class="single-product-item">
						<h3><br>EMS</h3>
						<p class="product-price"><span><br>Nama Pemilik: Tika<br><br>
                        Daehak-ro, Gunsan No. 254<br>
                        Post Code 54126<br>
                        No Telp. 010-8629-5913<br>
                        </span>
                        </p>
						
					</div>
				</div>
                <div class="col-lg-6 col-md-6 text-center">
					<div class="single-product-item">
						<h3><br>Air Cargo</h3>
						<p class="product-price"><span><br>Nama Pemilik: Nurantika<br><br>
                        Daehak-ro, Gunsan No. 254<br>
                        Post Code 54126<br>
                        No Telp. 010-8629-5913<br>
                        </span>
                        </p>
						
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!-- end team section -->

<!-- copyright -->
<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2022 - Cloudify Warehouse,  All Rights Reserved.
					</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="https://twitter.com/cloudifythings" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="https://instagram.com/cloudify.things" target="_blank"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->
	
	<!-- jquery -->
	<script src="<?= base_url() ?>assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="<?= base_url() ?>assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="<?= base_url() ?>assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="<?= base_url() ?>assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="<?= base_url() ?>assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="<?= base_url() ?>assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="<?= base_url() ?>assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="<?= base_url() ?>assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="<?= base_url() ?>assets/js/main.js"></script>

</body>
</html>

<!doctype html>
<html lang="en">

<head>
    <title>Cetak Data</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title><?= $title; ?></title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?= base_url() ?>assets/img/cw.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/responsive.css">

    <style>
        .page-title {
        text-align: center;
        }

        @media print {
        	h1, h2 {
        		text-align: center;
        	}
        	.table td, .table th { padding: 0px; }
        }
		img{
			width: 130px;
			height: 130px;
		}
    </style>
</head>

<body>
	<span class="page-title">
		<div class="row">
					<div>
					<img src="<?= base_url() ?>assets/img/logo-login.png"> 
					</div>
					<div class="col text-center">
					<br>
					<h3>Cloudify Warehouse</h3>
					<h4>Layanan Sewa Jasa Warehouse</h4>
					</div>
		</div>
		
		<hr>
	    <h2>Laporan Rekap Data Barang</h2>
	    <h3>Bulan <?= en_month_to_ina(date('n', strtotime($resi_list[0]['tanggal_masuk']))); ?> Tahun <?= date('Y') ?></h3>
	</span>
    <?php if (count($resi_list) < 1): ?>
    	Tidak ada data yang dapat ditampilkan
    <?php else: ?>
    	<table class="table mt-3">
    		<thead>
    			<tr>
					<th scope="col">No</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Resi</th>
                    <th scope="col">Nama Barang</th>
                    <th scope="col">Jumlah</th>
	    		</tr>
	    	</thead>
	    	<tbody>
		    	<?php $total_jumlah = 0; foreach ($resi_list as $no => $resi): ?>
					<tr>
		                <td scope="row"><?= $no + 1 ?></td>
		                <td><?= date('d-m-Y H:i', strtotime($resi['tanggal_masuk'])); ?></td>
						<td><?= $resi['resi']; ?></td>
                        <td><?= $resi['nama_barang']; ?></td>
                        <td><?= $resi['jumlah_barang']; ?></td>
		            </tr>
			    <?php $total_jumlah += (int) $resi['jumlah_barang']; endforeach ?>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="4" style="text-align: right;"></td>
					<td><?= number_format($total_jumlah ?: 0, 0, ',', '.') ?></td>
				</tr>
			</tfoot>
	    </table>

	    <script>
	        window.print();
	    </script>
    <?php endif ?>
</body>

</html>
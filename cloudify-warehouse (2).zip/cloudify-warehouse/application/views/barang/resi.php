<?php
	$flash = $this->session->flashdata('resi_uploaded');
	$form_flash = $this->session->flashdata('form');
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title><?= $title; ?></title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?= base_url() ?>assets/img/cw.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/responsive.css">

</head>
<body>
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="<?= base_url() ?>assets/img/random.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li><a href="<?= base_url('beranda') ?>">Beranda</a></li>
								<li><a href="<?= base_url('tentang') ?>">Tentang Kami</a></li>
								<li  class="current-list-item"><a href="#">Barang</a>
									<ul class="sub-menu">
										<li><a href="<?= base_url('barang/resi') ?>">Resi</a></li>
										<li><a href="<?= base_url('barang/status') ?>">Lacak Pengiriman</a></li>
										<li><a href="<?= base_url('barang/tagihan') ?>">Transaksi</a></li>
									</ul>
								</li>
								<li><a href="<?= base_url('profil') ?>">Profil</a></li>
								<li>
									<div class="header-icons">
										<a class="shopping-cart" href=""></a>
										<a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->
	
	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<input type="text" placeholder="Keywords">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search area -->
	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
	</div>
	<!-- end breadcrumb section -->


	<!-- team section -->
	<div class="mt-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="section-title">
						<h3>Formulir <span class="orange-text">Resi</span></h3>
						<p>Isi dengan informasi barang yang Anda dapatkan dari pesanan Anda</p>
					</div>
				</div>
			</div>
			<?php if (isset($flash)): ?>
				<?php if ($flash == 2): ?>
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
						Resi gagal dimasukkan: <?= $this->session->flashdata('resi_failed_message'); ?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php else: ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
						Resi berhasil dimasukkan
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php endif ?>
			<?php endif ?>
			<div class="contact-from-section mb-150">
				 	<div id="form_status"></div>
					<div class="contact-form">
						<form method="post" id="fruitkha-contact" action="<?= base_url('barang/simpanresi') ?>" enctype="multipart/form-data">
							<div class="form-group">
								<label>Nama Barang</label>
								<input type="text" class="form-control form-control-user" id="nama_barang" name="nama_barang" value='<?= $form_flash['nama_barang'] ?? NULL ?>' style="border-radius: 10rem;height: 3.12rem; font-size: .8rem" placeholder="Nama Barang" required>
							</div>
							<div class="form-group">
								<label>Jumlah Barang</label>
								<input type="text" class="form-control form-control-user" id="jumlah_barang" name="jumlah_barang" value='<?= $form_flash['jumlah_barang'] ?? NULL ?>' style="border-radius: 10rem;height: 3.12rem; font-size: .8rem" placeholder="Jumlah Barang" required>
							</div>
							<div class="form-row">
							<div class="form-group col-md-6">
								<label>Resi</label>
								<input type="text" class="form-control form-control-user" id="resi" name="resi" value='<?= $form_flash['resi'] ?? NULL ?>' style="border-radius: 10rem;height: 3.12rem; font-size: .8rem" placeholder="Resi" required>
							</div>
							<div class="form-group col-md-6">
								<label>Tanggal Kirim</label>
								<input type="date" class="form-control form-control-user" id="tgl_kirim" name="tgl_kirim" value='<?= $form_flash['tgl_kirim'] ?? NULL ?>' style="border-radius: 10rem;height: 3.12rem; font-size: .8rem" placeholder="Tanggal Kirim" required>
							</div>
							</div>
							<div class="form-row">
							<div class="form-group col-md-6">
								<label for="paket_id">Jenis Paket</label>
								<select class="form-control" name="paket_id" id="paket_id" style="border-radius: 10rem;height: 3.12rem; font-size: .8rem">
								<?php $i = 1; foreach ($paket_list as $list): ?>
										<option value="<?= $list['paket_id'] ?>"><?= $list['nama_paket'] ?></option>
									<?php $i++; endforeach ?>
								</select>
							</div>
							<div class="form-group col-md-6">
								<label for="pengiriman_id">Jenis Ekspedisi</label>
								<select class="form-control" name="pengiriman_id" id="pengiriman_id" style="border-radius: 10rem;height: 3.12rem; font-size: .8rem">
									<?php $i = 1; foreach ($pengiriman_list as $list): ?>
										<option value="<?= $i ?>"><?= $list['nama_pengiriman'] ?></option>
										<?php $i++; endforeach ?>
								</select>
							</div>
							</div>
							<div class="form-group">
								<label>Gambar Barang / Bukti Pesanan</label>
								<input type="file" class="form-control form-control-user" id="gambar_barang" name="gambar_barang" style="border-radius: 10rem;height: 3.12rem; font-size: .8rem" placeholder="Gambar Barang" required>
							</div>
							<div class="form-group">
								<button type="submit" class="form-control btn btn-dark rounded submit px-3">Submit</button>
							</div>
						</form>
					</div>
				</div>
		</div>
	</div>
	<!-- end team section -->

<!-- copyright -->
<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2022 - Cloudify Warehouse,  All Rights Reserved.
					</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="https://twitter.com/cloudifythings" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="https://instagram.com/cloudify.things" target="_blank"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->
	
	<!-- jquery -->
	<script src="<?= base_url() ?>assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="<?= base_url() ?>assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="<?= base_url() ?>assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="<?= base_url() ?>assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="<?= base_url() ?>assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="<?= base_url() ?>assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="<?= base_url() ?>assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="<?= base_url() ?>assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="<?= base_url() ?>assets/js/main.js"></script>

</body>
</html>

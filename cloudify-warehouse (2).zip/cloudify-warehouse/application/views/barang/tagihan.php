<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title><?= $title; ?></title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?= base_url() ?>assets/img/cw.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/responsive.css">

</head>
<body>
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="<?= base_url() ?>assets/img/random.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li><a href="<?= base_url('beranda') ?>">Beranda</a></li>
								<li><a href="<?= base_url('tentang') ?>">Tentang Kami</a></li>
								<li class="current-list-item"><a href="#">Barang</a>
									<ul class="sub-menu">
										<li><a href="<?= base_url('barang/resi') ?>">Resi</a></li>
										<li><a href="<?= base_url('barang/status') ?>">Lacak Pengiriman</a></li>
										<li><a href="<?= base_url('barang/tagihan') ?>">Transaksi</a></li>
									</ul>
								</li>
								<li><a href="<?= base_url('profil') ?>">Profil</a></li>
								<li>
									<div class="header-icons">
										<a class="shopping-cart" href=""></a>
										<a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->
	
	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<input type="text" placeholder="Keywords">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search area -->

<!-- breadcrumb-section -->
<div class="breadcrumb-section breadcrumb-bg">
</div>
<!-- end breadcrumb section -->

<!-- team section -->
<div class="mt-150">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 offset-lg-2 text-center">
				<div class="section-title">
					<h3>Tagihan <span class="orange-text">Tarif</span></h3>
				</div>
			</div>
		</div>
		<ul class="nav nav-pills mb-3 nav-justified" id="pills-tab" role="tablist">
			<li class="nav-item">
				<a class="nav-link active" id="pills-tagihan-tab" data-toggle="pill" href="#pills-tagihan" role="tab" aria-controls="pills-tagihan" aria-selected="true">Tagihan</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" id="pills-riwayat-tagihan-tab" data-toggle="pill" href="#pills-riwayat-tagihan" role="tab" aria-controls="pills-riwayat-tagihan" aria-selected="false">Riwayat Tagihan</a>
			</li>
		</ul>
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-tagihan" role="tabpanel" aria-labelledby="pills-tagihan-tab">
				<?php if (count($alltagihan) > 0): ?>
					<?php foreach ($alltagihan as $no => $tagihan): ?>
						<div class="card">
							<div class="card-header">
								<div class="row">
									<div class="col">
										No Resi : <?= $tagihan['resi']; ?>
									</div>
									<div class="col text-right">
										<a href="<?= base_url('barang/detail_tagihan/'.$tagihan['tagihan_id']) ?>" class="btn btn-dark">Detail</a>
									</div>
								</div>
							</div>
							<div class="card-body">
								<div class="row">
									<div class="col">
										<h5 class="card-title">BOX <?= $tagihan['box']; ?> <?= $tagihan['nama_pengiriman']; ?> - <?= $tagihan['nama_paket']; ?></h5>
									</div>
									<div class="col text-right">
										<p class="card-text">Rp<?= number_format($tagihan['jumlah'] ?: 0, 0,',','.'); ?></p>
									</div>
								</div>
							</div>
						</div>
						<br>
					<?php endforeach ?>
				<?php else: ?>
					<div class="card">
						<div class="card-body">
							Tidak ada data tagihan belum terbayar
						</div>
					</div>
				<?php endif ?>

				<!-- page container -->
				<div class="mb-150">
					<div class="row">
						<div class="container">
							<div class="row">
								<div class="col-lg-12 text-center">
									<div class="pagination-wrap">
										<ul>
											<li><a href="#">Prev</a></li>
											<li><a href="#">1</a></li>
											<li><a class="active" href="#">2</a></li>
											<li><a href="#">3</a></li>
											<li><a href="#">Next</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="pills-riwayat-tagihan" role="tabpanel" aria-labelledby="pills-riwayat-tagihan-tab">
				<?php if (count($riwayat_tagihan) > 0): ?>
					<?php foreach ($riwayat_tagihan as $no => $tagihan): ?>
						<div class="card">
							<div class="card-header">
								<div class="row">
									<div class="col">
										No Resi : <?= $tagihan['resi']; ?>
									</div>
									<div class="col text-right">
										<a href="<?= base_url('barang/detail_tagihan/'.$tagihan['tagihan_id']) ?>" class="btn btn-dark">Detail</a>
									</div>
								</div>
							</div>
							<div class="card-body">
								<div class="row">
									<div class="col">
										<h5 class="card-title">BOX <?= $tagihan['box']; ?> <?= $tagihan['nama_pengiriman']; ?> - <?= $tagihan['nama_paket']; ?></h5>
									</div>
									<div class="col text-right">
										<p class="card-text">Rp<?= number_format($tagihan['jumlah'] ?: 0, 0,',','.'); ?></p>
									</div>
								</div>
							</div>
						</div>
						<br>
					<?php endforeach ?>
				<?php else: ?>
					<div class="card">
						<div class="card-body">
							Tidak ada data tagihan berhasil
						</div>
					</div>
				<?php endif ?>
				
				<!-- page container -->
				<div class="mb-150">
					<div class="row">
						<div class="container">
							<div class="row">
								<div class="col-lg-12 text-center">
									<div class="pagination-wrap">
										<ul>
											<li><a href="#">Prev</a></li>
											<li><a class="active" href="#">1</a></li>
											<li><a href="#">2</a></li>
											<li><a href="#">3</a></li>
											<li><a href="#">Next</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br>
	</div>
</div>
<!-- end team section -->

<!-- copyright -->
<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2022 - Cloudify Warehouse,  All Rights Reserved.
					</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="https://twitter.com/cloudifythings" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="https://instagram.com/cloudify.things" target="_blank"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->
	
	<!-- jquery -->
	<script src="<?= base_url() ?>assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="<?= base_url() ?>assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="<?= base_url() ?>assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="<?= base_url() ?>assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="<?= base_url() ?>assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="<?= base_url() ?>assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="<?= base_url() ?>assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="<?= base_url() ?>assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="<?= base_url() ?>assets/js/main.js"></script>

</body>
</html>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pemilik extends CI_Controller
{

    public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
        $this->load->model('UserModel', 'um');
        $this->load->model('ResiModel', 'rm');
        $this->load->model('LogistikModel', 'lm');
        $this->load->model('TagihanModel', 'tgm');
        $this->load->model('TarifModel', 'tm');
        $this->load->model('FeeModel', 'fm');
        $this->load->model('LinkModel', 'lkm');
        $this->load->model('MetodePembayaranModel', 'mpm');

        // **
		// get user session
		$this->user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

	}

    public function index()
    {
        $data['title'] = "Data Barang Warehouse";
        $data['allresi'] = $this->rm->get_all_data_resi();
        $data['user'] = $this->user;

        $this->load->view('pemilik/data_barang', $data);
    }

    public function cetak_laporan_barang() {
		try {
			$data['resi_list'] = $this->rm->get_all_data_resi(array('MONTH(r.created_at)' => date('m')));
			$data['metode_pembayaran_list'] = $this->mpm->get_all_data_metode();
		} catch (Exception $e) {
			echo "<pre>";
			print_r($e->getMessage());
			echo "</pre>";
			exit;
		}
		$this->load->view('pemilik/barang_bulanan_print', $data);
	}

    public function logistik()
    {
        $data['title'] = "Data Pengiriman Warehouse";
        $data['alllogistik'] = $this->lm->group_logistik();
        $data['user'] = $this->user;

        $this->load->view('pemilik/data_logistik', $data);
    }

    public function cetak_laporan_logistik() {
		try {
			$data['logistik_list'] = $this->lm->group_logistik(array('MONTH(l.created_at)' => date('m')));
			$data['total_jumlah'] = count($this->lm->group_logistik(array('MONTH(l.created_at)' => date('m'))));
		} catch (Exception $e) {
			echo "<pre>";
			print_r($e->getMessage());
			echo "</pre>";
			exit;
		}
		$this->load->view('pemilik/logistik_bulanan_print', $data);
	}

    public function tagihan()
    {
        $data['title'] = "Data Transaksi Warehouse";
        $data['alltagihan'] = $this->tgm->get_all_data_tagihan();
        $data['user'] = $this->user;

        $this->load->view('pemilik/data_tagihan', $data);
    }

    public function cetak_laporan_tagihan() {
		try {
			$data['tagihan_list'] = $this->tgm->get_all_data_tagihan(array('MONTH(tg.created_at)' => date('m')));
			$data['metode_pembayaran_list'] = $this->mpm->get_all_data_metode();
		} catch (Exception $e) {
			echo "<pre>";
			print_r($e->getMessage());
			echo "</pre>";
			exit;
		}
		$this->load->view('pemilik/tagihan_bulanan_print', $data);
	}

	function cari($search_by)
	{
		try {
			// like condition
			$filters = array();

			// keyword to search
			$keyword = $this->input->post('keyword');
			switch ($search_by) {
				// menu Data Barang
				case 'resi':
					if ($keyword != NULL) $filters['r.resi'] = $keyword;
					$data['list'] = $this->rm->get_all_data_resi(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_barang';
					break;
				case 'ekspedisi':
					if ($keyword != NULL) $filters['pg.nama_pengiriman'] = $keyword;
					$data['list'] = $this->rm->get_all_data_resi(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_barang';
					break;
				// menu Data Pengiriman
				case 'status_pengiriman':
					if ($keyword != NULL) $filters['l.status'] = $keyword;
					$data['list'] = $this->lm->get_all_data_logistik(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_pengiriman';
					break;
				case 'resi_barang':
					if ($keyword != NULL) $filters['r.resi'] = $keyword;
					$data['list'] = $this->lm->get_all_data_logistik(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_pengiriman';
					break;
				case 'resi_pengiriman':
					if ($keyword != NULL) $filters['l.resi_pengiriman'] = $keyword;
					$data['list'] = $this->lm->get_all_data_logistik(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_pengiriman';
					break;
				// menu Data Transaksi
				case 'status_tagihan':
					if ($keyword != NULL) $filters['tg.status_tf'] = $keyword;
					$data['list'] = $this->tgm->get_all_data_tagihan(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_tagihan';
					break;
				case 'resi_barang_tagihan':
					if ($keyword != NULL) $filters['r.resi'] = $keyword;
					$data['list'] = $this->tgm->get_all_data_tagihan(NULL, $filters ?? NULL);
					$load_view = 'admin/cari/tabel_tagihan';
					break;
				default:
					throw new Exception('Cannot search by '.$search_by, 400);
					break;
			}
			
			$this->load->view($load_view, $data, FALSE);
		} catch (Exception $e) {
			http_response_code($e->getCode() ?: 400);
			echo json_encode($e->getMessage() ?: 'Unknown error encountered');
		}
	}
	
}
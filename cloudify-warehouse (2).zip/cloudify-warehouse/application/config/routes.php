<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Landing';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'auth';
$route['daftar'] = 'user/registration';
$route['profil'] = 'user/profile';

$route['beranda'] = 'home/index';
$route['tentang'] = 'home/tentang';

$route['barang/resi'] = 'barang/form';
$route['barang/status'] = 'barang/status';
$route['barang/detail_status'] = 'barang/detail_status';
$route['barang/tagihan'] = 'barang/tagihan';
$route['barang/detail_tagihan'] = 'barang/detail_tagihan';
$route['barang/upload-bukti'] = 'barang/upload_bukti_transfer';

$route['admin/data_user'] = 'admin/index';
$route['admin/data_barang'] = 'admin/barang';
$route['admin/data_logistik'] = 'admin/logistik';
$route['admin/data_tagihan'] = 'admin/tagihan';
$route['admin/data_tarif'] = 'admin/tarif';
$route['admin/data_fee'] = 'admin/fee';
$route['admin/data_metode'] = 'admin/metode_pembayaran';
$route['admin/data_link'] = 'admin/link';

$route['admin/cari/(:any)'] = 'admin/cari/$1';

$route['pemilik/data_barang'] = 'pemilik/index';
$route['pemilik/data_logistik'] = 'pemilik/logistik';
$route['pemilik/data_tagihan'] = 'pemilik/tagihan';

$route['pemilik/cari/(:any)'] = 'pemilik/cari/$1';
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2022 at 02:27 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cloudify_warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `fee_warehouse`
--

CREATE TABLE `fee_warehouse` (
  `fee_id` int(11) NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `fee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fee_warehouse`
--

INSERT INTO `fee_warehouse` (`fee_id`, `keterangan`, `fee`) VALUES
(1, 'Amplop', 10000),
(2, '1 kg', 10000),
(3, '> 1 - 2 kg', 15000),
(4, '> 2 - 4 kg', 20000),
(5, '> 4 - 8 kg', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_paket`
--

CREATE TABLE `jenis_paket` (
  `paket_id` int(11) NOT NULL,
  `nama_paket` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_paket`
--

INSERT INTO `jenis_paket` (`paket_id`, `nama_paket`) VALUES
(1, 'Sharing'),
(2, 'Direct (Repack)'),
(3, 'Direct (No Repack)');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_pengiriman`
--

CREATE TABLE `jenis_pengiriman` (
  `pengiriman_id` int(11) NOT NULL,
  `nama_pengiriman` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_pengiriman`
--

INSERT INTO `jenis_pengiriman` (`pengiriman_id`, `nama_pengiriman`) VALUES
(1, 'EMS'),
(2, 'Air Cargo');

-- --------------------------------------------------------

--
-- Table structure for table `link_checkout`
--

CREATE TABLE `link_checkout` (
  `link_id` int(11) NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `link_checkout`
--

INSERT INTO `link_checkout` (`link_id`, `keterangan`, `link`) VALUES
(1, 'Amplop 1 - 3 Resi', 'https://shp.ee/6smfc7x'),
(2, 'Amplop > 3 Resi', 'https://shp.ee/tams3mx\r\n'),
(4, 'Box 1 Kg', 'https://shp.ee/iqgduif'),
(5, 'Box 2 Kg', 'https://shp.ee/7waiwkf'),
(6, 'Box 3 Kg', 'https://shp.ee/tmdb6if'),
(7, 'Box 4-5 Kg', 'https://shp.ee/jej8fcf'),
(8, 'Box 6-7 Kg', 'https://shp.ee/6zmtd2f'),
(9, 'Box 8-9 Kg', 'https://shp.ee/xixbe8f'),
(10, 'Box 10-11 Kg', 'https://shp.ee/6wwsd2f');

-- --------------------------------------------------------

--
-- Table structure for table `logistik`
--

CREATE TABLE `logistik` (
  `log_id` int(11) NOT NULL,
  `resi_id` int(11) NOT NULL,
  `box` int(11) NOT NULL,
  `resi_pengiriman` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `gambar_arrived_kr` varchar(100) NOT NULL,
  `gambar_arrived_ina` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logistik`
--

INSERT INTO `logistik` (`log_id`, `resi_id`, `box`, `resi_pengiriman`, `status`, `gambar_arrived_kr`, `gambar_arrived_ina`, `created_at`, `updated_at`) VALUES
(3, 3, 20, 'EG294841965KR', 'Tiba di Warehouse Korea', 'log-3_arrived_kr.jpg', 'log-3_arrived_kr.jpg', '2022-07-29 06:53:11', '2022-07-02 12:59:10'),
(4, 4, 20, 'EG294841965KR', 'Bea Cukai', '', '', '2022-07-10 14:09:38', '2022-07-02 12:59:10'),
(6, 3, 11, 'EG68384109134', 'Tiba di Warehouse Korea', '', '', '2022-07-16 12:42:36', '2022-07-16 12:42:36'),
(9, 1, 28, 'EG20212223240', 'Tiba di Warehouse Korea', '', '', '2022-07-29 14:33:27', '2022-07-29 14:33:27'),
(10, 5, 10, 'EC0349740343', 'Tiba di Warehouse Korea', 'log-10_arrived_kr.jpg', 'log-10_arrived_ina.jpg', '2022-07-31 10:39:12', '2022-07-30 05:55:32'),
(11, 6, 20, 'EG68384109134', 'Tiba di Warehouse Indonesia', 'log-11_arrived_kr.jpg', 'log-11_arrived_ina.jpg', '2022-07-30 06:31:51', '2022-07-30 06:02:00'),
(12, 2, 10, 'EC0349740343', 'Tiba di Warehouse Korea', '', '', '2022-07-30 07:04:11', '2022-07-30 07:04:11'),
(13, 7, 44, 'EG20212223240', 'Tiba di Warehouse Korea', '', '', '2022-07-30 13:28:00', '2022-07-30 13:28:00'),
(14, 8, 30, 'EG20212223240', 'Tiba di Warehouse Korea', 'log-14_arrived_kr.jpg', 'log-14_arrived_ina.jpg', '2022-08-06 08:01:48', '2022-07-31 10:12:36'),
(15, 9, 58, 'EG68384109135', 'Tiba di Warehouse Korea', '', '', '2022-08-07 07:47:02', '2022-08-07 07:47:02'),
(16, 10, 58, 'EG68384109135', 'Tiba di Warehouse Korea', '', '', '2022-08-07 07:47:34', '2022-08-07 07:47:34'),
(17, 11, 59, 'EG68384109134', 'Tiba di Warehouse Korea', '', '', '2022-08-07 07:47:55', '2022-08-07 07:47:55'),
(18, 14, 60, 'EC0349740343', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:05:55', '2022-08-07 08:05:55'),
(19, 14, 60, 'EC0349740343', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:05:55', '2022-08-07 08:05:55'),
(20, 15, 60, 'EC0349740343', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:11:35', '2022-08-07 08:11:35'),
(21, 16, 61, 'EG68384109138', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:12:10', '2022-08-07 08:12:10'),
(22, 17, 61, 'EG68384109134', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:12:35', '2022-08-07 08:12:35'),
(23, 18, 70, 'EG20212223240', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:15:11', '2022-08-07 08:15:11'),
(24, 12, 64, 'EG68384109134', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:15:29', '2022-08-07 08:15:29'),
(25, 13, 65, 'EG68384109135', 'Tiba di Warehouse Korea', '', '', '2022-08-07 08:15:49', '2022-08-07 08:15:49');

-- --------------------------------------------------------

--
-- Table structure for table `metode_pembayaran`
--

CREATE TABLE `metode_pembayaran` (
  `metode_id` int(11) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `no_rek` varchar(30) NOT NULL,
  `pemilik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metode_pembayaran`
--

INSERT INTO `metode_pembayaran` (`metode_id`, `metode_pembayaran`, `no_rek`, `pemilik`) VALUES
(1, 'ShopeePay', '0895361169109', 'cloudify.things'),
(4, 'DANA / OVO / GoPay', '0895361169109', 'Nurantika'),
(5, 'Mandiri Syariah', '7149859777', 'Nurantika Kulka'),
(6, 'BCA', '7005561922', 'Nurantika Kulka');

-- --------------------------------------------------------

--
-- Table structure for table `resi`
--

CREATE TABLE `resi` (
  `resi_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_barang` varchar(200) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `resi` varchar(100) NOT NULL,
  `tgl_kirim` date NOT NULL,
  `paket_id` int(11) NOT NULL,
  `pengiriman_id` int(11) NOT NULL,
  `gambar_barang` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resi`
--

INSERT INTO `resi` (`resi_id`, `user_id`, `nama_barang`, `jumlah_barang`, `resi`, `tgl_kirim`, `paket_id`, `pengiriman_id`, `gambar_barang`, `created_at`) VALUES
(9, 8, '1 set Album Dimension:Answer ENHYPEN ', 2, '645938926512', '2022-08-07', 1, 1, 'pst.jpg', '2022-08-07 07:18:45'),
(10, 8, '1 set Album ENHYPEN Dimension:Answer', 2, '645930686462', '2022-08-05', 1, 1, 'IMG-20220115-WA0007.jpg', '2022-08-07 07:20:45'),
(11, 8, '1 set Album ENHYPEN Dimension:Answer', 2, '2410-3130-7333', '2022-08-05', 1, 1, 'IMG-20220119-WA0010.jpg', '2022-08-07 07:23:33'),
(12, 8, '1 GGU GGU PACKAGE ENHYPEN', 1, '557711640274', '2022-08-06', 2, 1, 'gguggu.jpg', '2022-08-07 07:25:46'),
(13, 8, '1 Membership Kit ENHYPEN', 1, '557712760451', '2022-08-07', 2, 1, 'Picsart_22-04-23_04-09-34-986.jpg', '2022-08-07 07:27:37'),
(14, 8, 'Album Dimension : Senkou ENHYPEN (7 Set)', 7, '557713110996', '2022-08-06', 1, 2, 'senkou.jpg', '2022-08-07 07:30:20'),
(15, 8, '6 Album Enhypen Manifesto', 6, '557718939060', '2022-08-07', 1, 1, 'manifesto.jpg', '2022-08-07 07:33:08'),
(16, 8, '6 Album ENHYPEN Manifesto', 6, '649652415441', '2022-08-07', 1, 1, 'IMG_20220720_160429.jpg', '2022-08-07 07:35:05'),
(17, 8, '4 Album ENHYPEN Manifesto', 4, '649717733222', '2022-08-07', 1, 1, 'IMG-20220711-WA0013.jpg', '2022-08-07 07:36:49'),
(18, 8, '4 Album ENHYPEN Manifesto', 4, '243445159661', '2022-08-07', 1, 1, 'IMG-20220714-WA0003.jpg', '2022-08-07 07:39:08');

-- --------------------------------------------------------

--
-- Table structure for table `tagihan`
--

CREATE TABLE `tagihan` (
  `tagihan_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `berat` varchar(11) DEFAULT NULL,
  `tarif_id` int(11) NOT NULL,
  `fee_id` int(11) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `bukti_tf` varchar(100) DEFAULT NULL,
  `status_tf` varchar(50) DEFAULT NULL,
  `link_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tagihan`
--

INSERT INTO `tagihan` (`tagihan_id`, `log_id`, `berat`, `tarif_id`, `fee_id`, `jumlah`, `bukti_tf`, `status_tf`, `link_id`, `created_at`) VALUES
(1, 1, '2400', 1, 1, '336000', '\r\n', 'Pembayaran Berhasil', 1, '2022-07-03 12:48:23'),
(12, 1, '2400', 2, 1, '336000', NULL, 'Pembayaran Belum Diterima', 1, '2022-07-17 11:56:50'),
(14, 4, '1500', 2, 2, '272500', NULL, 'Pembayaran Belum Diterima', 0, '2022-07-28 12:19:25'),
(15, 3, '200', 2, 1, '45000', NULL, 'Pembayaran Belum Diterima', 1, '2022-07-28 14:40:26'),
(16, 5, '3000', 4, 4, '875000', NULL, 'Pembayaran Belum Diterima', 1, '2022-07-28 14:43:29'),
(17, 7, '1500', 2, 3, '277500', NULL, 'Pembayaran Berhasil', 1, '2022-07-29 07:53:26'),
(18, 11, '2000', 4, 3, '585000', 'bukti_tf_384798410034019.jpg', 'Pembayaran Berhasil', 1, '2022-07-30 06:06:40'),
(21, 13, '500', 4, 2, '152500', 'bukti_tf_2983014093404.jpg', 'Pembayaran Belum Diterima', 1, '2022-07-30 13:28:27'),
(22, 14, '3000', 2, 4, '545000', 'bukti_tf_931083093003.jpg', 'Pembayaran Belum Diterima', 1, '2022-07-31 10:13:55'),
(23, 10, '2000', 2, 3, '365000', NULL, '-- Pilih Status --', 1, '2022-08-01 13:23:04'),
(24, 15, '700', 2, 2, '132500', 'bukti_tf_645938926512.jpg', 'Pembayaran Belum Diterima', 1, '2022-08-07 08:02:28'),
(25, 16, '700', 2, 2, '132500', NULL, 'Pembayaran Belum Diterima', 0, '2022-08-07 08:16:27'),
(26, 16, '700', 2, 2, '132500', NULL, 'Pembayaran Belum Diterima', 0, '2022-08-07 08:16:52'),
(27, 16, '700', 2, 2, '132500', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:17:45'),
(28, 17, '1230', 4, 3, '365550', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:18:41'),
(29, 20, '890', 2, 2, '165750', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:19:16'),
(30, 20, '1393', 2, 3, '258775', NULL, 'Pembayaran Belum Diterima', 2, '2022-08-07 08:19:59'),
(31, 21, '790', 2, 2, '148250', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:20:22'),
(32, 25, '1300', 2, 3, '242500', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:21:00'),
(33, 19, '1400', 2, 3, '260000', NULL, 'Pembayaran Belum Diterima', 1, '2022-08-07 08:21:22'),
(34, 18, '790', 2, 2, '148250', NULL, 'Pembayaran Belum Diterima', 9, '2022-08-07 08:21:45');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `tarif_id` int(11) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `tarif` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`tarif_id`, `keterangan`, `tarif`, `created_at`, `updated_at`) VALUES
(1, 'EMS Tax Barang Ringan / Paper Based', 5000, '2022-06-27 08:21:49', '2022-06-27 08:21:49'),
(2, 'EMS Tax Barang Berat / Barang Bervolume', 175, '2022-07-09 09:17:48', '2022-07-09 09:16:45'),
(3, 'Air Cargo Tax Barang Ringan / Paper Based', 6500, '2022-07-09 09:18:05', '2022-07-09 09:17:36'),
(4, 'Air Cargo Tax Barang Berat / Barang Bervolume', 285, '2022-07-09 09:18:18', '2022-07-09 09:17:36');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `no_telp` varchar(13) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text NOT NULL,
  `role_id` int(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `nama`, `jenis_kelamin`, `no_telp`, `email`, `password`, `avatar`, `role_id`, `created_at`) VALUES
(4, 'Jake', 'Laki-Laki', '085736738222', 'jake@gmail.com', '$2y$10$dY3RSuv9pMKctk2PWyCAh.fwzw1Qt1DXbjOX53Og7/5Nqm8OTg30G', 'jake.jpg', 2, '2022-07-10 13:37:43'),
(5, 'Jungwon', 'Laki-Laki', '089314994445', 'jungwon@gmail.com', '$2y$10$Nuau.66kLyDp3whemcC5CeZRioOSTzXBBhZRASnW83edmYlWcdiAu', 'jungwon.jpg', 1, '2022-07-10 13:37:43'),
(7, 'Taeil', 'Laki-Laki', '08975637489', 'taeil@gmail.com', '$2y$10$edhgIKX1GQcCV4RI4G/MFe/NPsID7tJvRmeDZywJvDg6LBkShwyzC', 'taeil.jpg', 3, '2022-07-28 12:16:17'),
(8, 'Jennie', 'Perempuan', '083747388933', 'jennie@gmail.com', '$2y$10$7GOE7/0OzU3ggYZgkBHBTOUBEoLtCJ22Sl.CAR8w0jziOG05yZNPC', 'default.jpg', 2, '2022-07-30 05:59:21');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `role`) VALUES
(1, 'Staff Warehouse'),
(2, 'Konsumen'),
(3, 'Pemilik Warehouse');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fee_warehouse`
--
ALTER TABLE `fee_warehouse`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `jenis_paket`
--
ALTER TABLE `jenis_paket`
  ADD PRIMARY KEY (`paket_id`);

--
-- Indexes for table `jenis_pengiriman`
--
ALTER TABLE `jenis_pengiriman`
  ADD PRIMARY KEY (`pengiriman_id`);

--
-- Indexes for table `link_checkout`
--
ALTER TABLE `link_checkout`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `logistik`
--
ALTER TABLE `logistik`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  ADD PRIMARY KEY (`metode_id`);

--
-- Indexes for table `resi`
--
ALTER TABLE `resi`
  ADD PRIMARY KEY (`resi_id`);

--
-- Indexes for table `tagihan`
--
ALTER TABLE `tagihan`
  ADD PRIMARY KEY (`tagihan_id`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`tarif_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fee_warehouse`
--
ALTER TABLE `fee_warehouse`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jenis_paket`
--
ALTER TABLE `jenis_paket`
  MODIFY `paket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jenis_pengiriman`
--
ALTER TABLE `jenis_pengiriman`
  MODIFY `pengiriman_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `link_checkout`
--
ALTER TABLE `link_checkout`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `logistik`
--
ALTER TABLE `logistik`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  MODIFY `metode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `resi`
--
ALTER TABLE `resi`
  MODIFY `resi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tagihan`
--
ALTER TABLE `tagihan`
  MODIFY `tagihan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tarif`
--
ALTER TABLE `tarif`
  MODIFY `tarif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

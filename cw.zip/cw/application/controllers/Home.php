<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

    public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('TarifModel', 'tm');
	}

    public function index()
    {
        $data['title'] = "Beranda";

        $this->load->view('templates/header', $data);
        $this->load->view('beranda', $data);
        $this->load->view('templates/footer');
    }
    public function tentang()
    {
        $data['alltarif'] = $this->tm->get_all_data_tarif();
        $data['title'] = "Tentang Kami";

        $this->load->view('templates/header', $data);
        $this->load->view('tentang', $data);
        $this->load->view('templates/footer');
    }
}
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function index()
    {
        $this->load->model('Auth_Model');
		$this->load->library('form_validation');

		$rules = $this->Auth_Model->rules();
		$this->form_validation->set_rules($rules);

		if($this->form_validation->run() == FALSE){
			return $this->load->view('login');
		}

		$email = $this->input->post('email');
		$password = $this->input->post('password');

		if($this->auth_model->login($email, $password)){
			redirect('admin');
		} else {
			$this->session->set_flashdata('message_login_error', 'Login Gagal, pastikan username dan passwrod benar!');
		}

		$this->load->view('login');
	}

	public function logout()
	{
		$this->load->model('Auth_Model');
		$this->auth_model->logout();
		redirect(site_url());
	}

    public function registration()
    {
        $this->load->view('daftar');
    }

	public function profile()
    {
        $data['title'] = "Profil";

        $this->load->view('templates/header', $data);
        $this->load->view('user/profil', $data);
        $this->load->view('templates/footer');
    }


}
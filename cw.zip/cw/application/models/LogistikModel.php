<?php

class LogistikModel extends CI_Model
{

    public function get_all_data_logistik()
    {
        $query = "SELECT l.*, r.*, p.nama_paket, pg.nama_pengiriman FROM logistik l, resi r, jenis_paket p, jenis_pengiriman pg 
        WHERE l.resi_id = r.resi_id AND r.paket_id = p.paket_id AND r.pengiriman_id = pg.pengiriman_id";
        return $this->db->query($query)->result_array();
    }

}
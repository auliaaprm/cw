-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2022 at 03:01 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cloudify_warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `fee_warehouse`
--

CREATE TABLE `fee_warehouse` (
  `fee_id` int(11) NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `fee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `jenis_paket`
--

CREATE TABLE `jenis_paket` (
  `paket_id` int(11) NOT NULL,
  `nama_paket` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_paket`
--

INSERT INTO `jenis_paket` (`paket_id`, `nama_paket`) VALUES
(1, 'Sharing'),
(2, 'Direct (Repack)'),
(3, 'Direct (No Repack)');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_pengiriman`
--

CREATE TABLE `jenis_pengiriman` (
  `pengiriman_id` int(11) NOT NULL,
  `nama_pengiriman` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_pengiriman`
--

INSERT INTO `jenis_pengiriman` (`pengiriman_id`, `nama_pengiriman`) VALUES
(1, 'EMS'),
(2, 'Air Cargo');

-- --------------------------------------------------------

--
-- Table structure for table `link_checkout`
--

CREATE TABLE `link_checkout` (
  `link_id` int(11) NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logistik`
--

CREATE TABLE `logistik` (
  `log_id` int(11) NOT NULL,
  `resi_id` int(11) NOT NULL,
  `box` int(11) NOT NULL,
  `resi_pengiriman` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `gambar_arrived_kr` varchar(100) NOT NULL,
  `gambar_arrived_ina` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logistik`
--

INSERT INTO `logistik` (`log_id`, `resi_id`, `box`, `resi_pengiriman`, `status`, `gambar_arrived_kr`, `gambar_arrived_ina`, `created_at`, `updated_at`) VALUES
(1, 1, 20, 'EG294841965KR', 'Bea Cukai', '', '', '2022-07-02 15:06:15', '2022-07-02 12:59:10');

-- --------------------------------------------------------

--
-- Table structure for table `resi`
--

CREATE TABLE `resi` (
  `resi_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_barang` varchar(200) NOT NULL,
  `resi` varchar(100) NOT NULL,
  `tgl_kirim` date NOT NULL,
  `paket_id` int(11) NOT NULL,
  `pengiriman_id` int(11) NOT NULL,
  `gambar_barang` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resi`
--

INSERT INTO `resi` (`resi_id`, `user_id`, `nama_barang`, `resi`, `tgl_kirim`, `paket_id`, `pengiriman_id`, `gambar_barang`, `created_at`) VALUES
(1, 1, 'Album Manifesto 6 Set', '557713110996', '2022-07-01', 1, 1, '2.jpg', '2022-07-02 12:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `tagihan`
--

CREATE TABLE `tagihan` (
  `tagihan_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `berat` int(11) DEFAULT NULL,
  `tarif_id` int(11) NOT NULL,
  `fee_id` int(11) NOT NULL,
  `jumlah` int(20) NOT NULL,
  `bukti_tf` varchar(100) DEFAULT NULL,
  `status_tf` varchar(20) DEFAULT NULL,
  `link_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tagihan`
--

INSERT INTO `tagihan` (`tagihan_id`, `log_id`, `berat`, `tarif_id`, `fee_id`, `jumlah`, `bukti_tf`, `status_tf`, `link_id`, `created_at`) VALUES
(1, 1, 2400, 1, 1, 336000, '\r\n', NULL, 1, '2022-07-03 12:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `tarif_id` int(11) NOT NULL,
  `tarif_ems_tax_paper` int(20) NOT NULL,
  `tarif_ems_tax_volume` int(20) NOT NULL,
  `tarif_ac_tax_paper` int(20) NOT NULL,
  `tarif_ac_tax_volume` int(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`tarif_id`, `tarif_ems_tax_paper`, `tarif_ems_tax_volume`, `tarif_ac_tax_paper`, `tarif_ac_tax_volume`, `created_at`, `updated_at`) VALUES
(1, 5000, 175, 6500, 285, '2022-06-27 08:21:49', '2022-06-27 08:21:49');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `jenis_kelamin`, `email`, `password`, `avatar`, `created_at`, `last_login`) VALUES
(1, 'Jake', 'Pria', 'jake001@gmail.com', '12345', NULL, '2022-06-26 08:09:16', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fee_warehouse`
--
ALTER TABLE `fee_warehouse`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `jenis_paket`
--
ALTER TABLE `jenis_paket`
  ADD PRIMARY KEY (`paket_id`);

--
-- Indexes for table `jenis_pengiriman`
--
ALTER TABLE `jenis_pengiriman`
  ADD PRIMARY KEY (`pengiriman_id`);

--
-- Indexes for table `link_checkout`
--
ALTER TABLE `link_checkout`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `logistik`
--
ALTER TABLE `logistik`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `resi`
--
ALTER TABLE `resi`
  ADD PRIMARY KEY (`resi_id`);

--
-- Indexes for table `tagihan`
--
ALTER TABLE `tagihan`
  ADD PRIMARY KEY (`tagihan_id`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`tarif_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fee_warehouse`
--
ALTER TABLE `fee_warehouse`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jenis_paket`
--
ALTER TABLE `jenis_paket`
  MODIFY `paket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jenis_pengiriman`
--
ALTER TABLE `jenis_pengiriman`
  MODIFY `pengiriman_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `link_checkout`
--
ALTER TABLE `link_checkout`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logistik`
--
ALTER TABLE `logistik`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `resi`
--
ALTER TABLE `resi`
  MODIFY `resi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tagihan`
--
ALTER TABLE `tagihan`
  MODIFY `tagihan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tarif`
--
ALTER TABLE `tarif`
  MODIFY `tarif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
